const express = require('express');
const session = require('express-session');
const flash = require('connect-flash');
const app = express();
const path = require('path');
const bodyParser = require('body-parser');
const productRoutes = require('./routes/products');
const authRouter = require('./routes/auth');
const billingRouter = require('./routes/billing');
const db = require('./db');

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');

// Session middleware
app.use(session({
  secret: 'your-secret-key',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false } // Set secure: true if using HTTPS
}));

// Flash middleware
app.use(flash());

// Middleware to expose session user and flash messages to views
app.use((req, res, next) => {
  res.locals.session = req.session;
  res.locals.success_msg = req.flash('success_msg');
  res.locals.error_msg = req.flash('error_msg');
  next();
});

// Middleware to protect routes
function isAuthenticated(req, res, next) {
  if (req.session && req.session.user) {
    return next();
  } else {
    console.log('Unauthorized access attempt to:', req.originalUrl);
    return res.redirect('/login');
  }
}

// Routes
app.use('/products', isAuthenticated, productRoutes);
app.use('/billing', isAuthenticated, billingRouter);
app.use('/', authRouter);

// Homepage redirect with login check and logging
app.get('/', (req, res) => {
    console.log('Session user:', req.session ? req.session.user : 'No session');
    if (req.session && req.session.user) {
        res.redirect('/products');
    } else {
        res.redirect('/login');
    }
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
