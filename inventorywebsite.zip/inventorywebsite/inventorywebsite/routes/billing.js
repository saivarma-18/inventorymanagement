const express = require('express');
const router = express.Router();
const db = require('../db');

// Middleware to check if user is authenticated
function isAuthenticated(req, res, next) {
    if (req.session && req.session.user) {
        return next();
    } else {
        req.flash('error_msg', 'You need to login to view this resource');
        res.redirect('/login');
    }
}

// Middleware to check if user is admin
function isAdmin(req, res, next) {
    if (req.session && req.session.role === 'admin') {
        next();
    } else {
        req.flash('error_msg', 'You are not authorized to view this resource');
        res.redirect('/login');
    }
}

// Show billing page (accessible to all authenticated users)
router.get('/', isAuthenticated, (req, res) => {
    // Get all products for the billing interface
    db.query('SELECT * FROM products WHERE quantity > 0', (err, products) => {
        if (err) {
            console.error(err);
            req.flash('error_msg', 'Error fetching products');
            return res.redirect('/');
        }
        res.render('billing', { products, role: req.session.role });
    });
});

// Create a new bill
router.post('/create', isAuthenticated, (req, res) => {
    const { customer_name, items } = req.body;
    
    if (!customer_name || !items || items.length === 0) {
        req.flash('error_msg', 'Please provide customer name and at least one item');
        return res.redirect('/billing');
    }
    
    // Calculate total amount
    let totalAmount = 0;
    const billItems = [];
    
    items.forEach(item => {
        const productId = item.product_id;
        const quantity = parseInt(item.quantity);
        const price = parseFloat(item.price);
        
        if (quantity > 0 && price > 0) {
            totalAmount += quantity * price;
            billItems.push([productId, quantity, price]);
        }
    });
    
    if (billItems.length === 0) {
        req.flash('error_msg', 'No valid items found');
        return res.redirect('/billing');
    }
    
    // Since we can't use transactions with the current db setup, we'll do it step by step
    // Insert bill
    db.query('INSERT INTO bills (customer_name, total_amount) VALUES (?, ?)', 
        [customer_name, totalAmount], 
        (err, result) => {
            if (err) {
                console.error(err);
                req.flash('error_msg', 'Error creating bill');
                return res.redirect('/billing');
            }
            
            const billId = result.insertId;
            
            // Process bill items one by one
            processBillItems(billId, billItems, 0, req, res);
        });
});

// Helper function to process bill items sequentially
function processBillItems(billId, billItems, index, req, res) {
    if (index >= billItems.length) {
        // All items processed successfully
        req.flash('success_msg', 'Bill created successfully');
        return res.redirect('/billing/view/' + billId);
    }
    
    const [productId, quantity, price] = billItems[index];
    
    // Check if sufficient quantity is available
    db.query('SELECT quantity FROM products WHERE id = ?', [productId], (err, results) => {
        if (err) {
            console.error(err);
            req.flash('error_msg', 'Error checking product quantity');
            return res.redirect('/billing');
        }
        
        if (results.length === 0 || results[0].quantity < quantity) {
            req.flash('error_msg', 'Insufficient quantity for product ID: ' + productId);
            return res.redirect('/billing');
        }
        
        // Insert bill item
        db.query('INSERT INTO bill_items (bill_id, product_id, quantity, price) VALUES (?, ?, ?, ?)',
            [billId, productId, quantity, price],
            (err) => {
                if (err) {
                    console.error(err);
                    req.flash('error_msg', 'Error adding bill items');
                    return res.redirect('/billing');
                }
                
                // Update product quantity
                db.query('UPDATE products SET quantity = quantity - ? WHERE id = ?',
                    [quantity, productId],
                    (err) => {
                        if (err) {
                            console.error(err);
                            req.flash('error_msg', 'Error updating product quantity');
                            return res.redirect('/billing');
                        }
                        
                        // Process next item
                        processBillItems(billId, billItems, index + 1, req, res);
                    });
            });
    });
}

// View all bills (admin only)
router.get('/all', isAdmin, (req, res) => {
    db.query('SELECT * FROM bills ORDER BY created_at DESC', (err, bills) => {
        if (err) {
            console.error(err);
            req.flash('error_msg', 'Error fetching bills');
            return res.redirect('/billing');
        }
        res.render('all-bills', { bills, role: req.session.role });
    });
});

// View specific bill
router.get('/view/:id', isAuthenticated, (req, res) => {
    const billId = req.params.id;
    
    // Get bill details
    db.query('SELECT * FROM bills WHERE id = ?', [billId], (err, bills) => {
        if (err) {
            console.error(err);
            req.flash('error_msg', 'Error fetching bill');
            return res.redirect('/billing');
        }
        
        if (bills.length === 0) {
            req.flash('error_msg', 'Bill not found');
            return res.redirect('/billing');
        }
        
        const bill = bills[0];
        
        // Get bill items with product names
        db.query(`SELECT bi.*, p.name as product_name 
                  FROM bill_items bi 
                  JOIN products p ON bi.product_id = p.id 
                  WHERE bi.bill_id = ?`, 
                  [billId], 
                  (err, items) => {
                    if (err) {
                        console.error(err);
                        req.flash('error_msg', 'Error fetching bill items');
                        return res.redirect('/billing');
                    }
                    
                    res.render('view-bill', { bill, items, role: req.session.role });
                });
    });
});

module.exports = router;
