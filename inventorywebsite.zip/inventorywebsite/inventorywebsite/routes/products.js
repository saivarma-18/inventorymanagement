const express = require('express');
const router = express.Router();
const db = require('../db');

// Middleware to check if user is admin
function isAdmin(req, res, next) {
    if (req.session && req.session.role === 'admin') {
        next();
    } else {
        req.flash('error_msg', 'You are not authorized to view this resource');
        res.redirect('/login');
    }
}

// Show all products or search by name or id

router.get('/', (req, res) => {
    const search = req.query.search;
    let query = 'SELECT * FROM products';
    let params = [];

    if (search) {
        query += ' WHERE name LIKE ? OR id = ?';
        params.push(`%${search}%`);
        params.push(search);
    }

    db.query(query, params, (err, results) => {
        if (err) {
            console.error(err);
            req.flash('error_msg', 'Error fetching products');
            return res.redirect('/');
        }
        // Flag products with quantity < 5 as lowStock and quantity > 40 as highStock
        results.forEach(product => {
            product.lowStock = product.quantity < 5;
            product.highStock = product.quantity > 40;
        });
        res.render('products', { products: results, search: search || '', role: req.session.role });
    });
});

// Add product form - only admin
router.get('/add', isAdmin, (req, res) => {
    res.render('add');
});

// Handle product add - only admin

router.post('/add', isAdmin, (req, res) => {
    const { name, quantity, price } = req.body;
    db.query('INSERT INTO products (name, quantity, price) VALUES (?, ?, ?)', [name, quantity, price], (err) => {
        if (err) {
            console.error(err);
            req.flash('error_msg', 'Error adding product');
            return res.redirect('/products/add');
        }
        req.flash('success_msg', 'New product was added into your inventory');
        res.redirect('/products');
    });
});

// Delete - only admin

router.get('/delete/:id', isAdmin, (req, res) => {
    const id = req.params.id;
    db.query('DELETE FROM products WHERE id = ?', [id], (err) => {
        if (err) {
            console.error(err);
            req.flash('error_msg', 'Error deleting product');
            return res.redirect('/products');
        }
        req.flash('success_msg', 'One product was removed from your store');
        res.redirect('/products');
    });
});

// Edit product form - only admin

router.get('/edit/:id', isAdmin, (req, res) => {
    const id = req.params.id;
    db.query('SELECT * FROM products WHERE id = ?', [id], (err, results) => {
        if (err) {
            console.error(err);
            req.flash('error_msg', 'Error fetching product details');
            return res.redirect('/products');
        }
        res.render('edit', { product: results[0] });
    });
});

// Handle edit - only admin

router.post('/edit/:id', isAdmin, (req, res) => {
    const id = req.params.id;
    const { name, quantity, price } = req.body;
    db.query('UPDATE products SET name = ?, quantity = ?, price = ? WHERE id = ?', [name, quantity, price, id], (err) => {
        if (err) {
            console.error(err);
            req.flash('error_msg', 'Error updating product');
            return res.redirect(`/products/edit/${id}`);
        }
        res.redirect('/products');
    });
});

// Show products by name
router.get('/name/:productName', (req, res) => {
    const productName = req.params.productName;
    db.query('SELECT * FROM products WHERE name = ?', [productName], (err, results) => {
        if (err) throw err;
        res.render('product-name', { products: results, productName });
    });
});

// New route to show user details - only admin
router.get('/admin/users', isAdmin, (req, res) => {
    db.query('SELECT username, role FROM users', (err, results) => {
        if (err) {
            console.error(err);
            req.flash('error_msg', 'Error fetching user details');
            return res.redirect('/products');
        }
        res.render('user-details', { users: results });
    });
});

module.exports = router;
