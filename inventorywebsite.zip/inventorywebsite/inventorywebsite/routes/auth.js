const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const db = require('../db');

// Debug logging middleware
router.use((req, res, next) => {
  console.log(`Auth route accessed: ${req.method} ${req.originalUrl}`);
  next();
});

// GET registration page
router.get('/register', (req, res) => {
  console.log('Rendering register page');
  res.render('register', { error: null });
});

// POST registration form
router.post('/register', async (req, res) => {
  const { username, password, role } = req.body;
  if (!username || !password) {
    return res.render('register', { error: 'Please provide username and password' });
  }
  try {
    // Check if user exists
    const [rows] = await db.promise().query('SELECT * FROM users WHERE username = ?', [username]);
    if (rows.length > 0) {
      return res.render('register', { error: 'Username already exists' });
    }
    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);
    // Default role to 'user' if not provided
    const userRole = role ? role : 'user';
    // Insert user with role
    await db.promise().query('INSERT INTO users (username, password, role) VALUES (?, ?, ?)', [username, hashedPassword, userRole]);
    res.redirect('/login');
  } catch (err) {
    console.error(err);
    res.render('register', { error: 'An error occurred. Please try again.' });
  }
});

// GET login page
router.get('/login', (req, res) => {
  if (req.session && req.session.user) {
    return res.redirect('/');
  }
  res.render('login', { error: null, isLoginPage: true });
});

// POST login form
router.post('/login', async (req, res) => {
  const { username, password, role } = req.body;
  try {
    const [rows] = await db.promise().query('SELECT * FROM users WHERE username = ?', [username]);
    if (rows.length === 0) {
      return res.render('login', { error: 'Invalid username or password' });
    }
    const user = rows[0];
    if (user.role !== role) {
      return res.render('login', { error: 'Selected role does not match user role' });
    }
    const match = await bcrypt.compare(password, user.password);
    if (match) {
      req.session.user = user.username;
      req.session.role = user.role;  // Add user role to session
      console.log('User role from DB:', user.role);
      console.log('Session role set to:', req.session.role);
      return res.redirect('/');
    } else {
      return res.render('login', { error: 'Invalid username or password' });
    }
  } catch (err) {
    console.error(err);
    res.render('login', { error: 'An error occurred. Please try again.' });
  }
});

// GET logout
router.get('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/login');
  });
});

module.exports = router;
